## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----createIndividualCharacteristics------------------------------------------
library(ospsuite)

individualCharacterstics <- createIndividualCharacteristics(species = Species$Human,
                                                            population = HumanPopulation$Japanese_Population,
                                                            gender = Gender$Female,
                                                            weight = 75,
                                                            height = 1.75,
                                                            heightUnit = "m",
                                                            age = 43)
print(individualCharacterstics)

individual <- createIndividual(individualCharacteristics = individualCharacterstics)

## ----setIndividualParameters--------------------------------------------------
library(ospsuite)

# Load simulation
simFilePath <- file.path(getwd(), "..", "tests", "data", "Aciclovir.pkml", fsep = .Platform$file.sep)
sim <- loadSimulation(simFilePath)

# Apply individual parameters
setParameterValuesByPath(parameterPaths = individual$distributedParameters$paths,
                         values = individual$distributedParameters$values,
                         simulation = sim)

