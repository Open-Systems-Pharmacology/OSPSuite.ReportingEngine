## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)
load("../data/pkRatioDataExample.RData")
load("../data/tlf-output.RData")
load("../data/timeProfileDataFrame.RData")
library(tlf)

## ---- out.width="100%", include=TRUE, fig.align="center", echo=FALSE----------
# echo=FALSE prints only code chunk output
knitr::include_graphics("workflow.png")

## ---- echo = FALSE, results='asis'--------------------------------------------
# This small script gives a fast way to introduce the nomenclature of the classes and functions
plotNames <- c("PKRatio", "TimeProfile", "Histogram", "BoxWhisker", "DDIRatio") #"GOF", 
classesNames <- c("DataMapping", "PlotConfiguration")
functionNames <- c("plot")

conventionTable <- data.frame(sapply(classesNames, function(x){paste0(plotNames, x)}), 
           sapply(functionNames, function(x){paste0(x, plotNames)}),
           row.names = plotNames)


knitr::kable(conventionTable)

## ---- echo=FALSE, results='asis'----------------------------------------------
testData <- outputValues$data
knitr::kable(head(testData)) #For aesthetics of the table align='c', digits =2)

## ---- results='asis', echo=FALSE----------------------------------------------
testMetaData <- outputValues$metaData
metaDataTable <- data.frame("unit" = sapply(testMetaData, function(x){x$unit}),
                            "dimension" = sapply(testMetaData, function(x){x$dimension}))

knitr::kable(metaDataTable)

## ---- results='asis'----------------------------------------------------------
aggSummary <- AggregationSummary$new(data = testData , 
                                     metaData = testMetaData,
                                     xColumnNames = "Time",
                                     groupingColumnNames = "Gender",
                                     yColumnNames = "Organism|ArterialBlood|Aciclovir|Whole Blood",
                                     aggregationFunctionsVector = c(min,mean),
                                     aggregationFunctionNames =c("Simulated Min",
                                                                 "Simulated Mean"),
                                     aggregationUnitsVector = c("�mol/l","�mol/l"),
                                     aggregationDimensionsVector = c("Concentration",
                                                                     "Concentration"))

## ---- echo=FALSE, results='asis'----------------------------------------------
knitr::kable(head(aggSummary$dfHelper, digits=2))

## ---- results='asis'----------------------------------------------------------
# Currently issue with metaData of Gender
aggSummary$metaDataHelper[[2]] <- NULL
aggMetaData <- data.frame("unit" = sapply(aggSummary$metaDataHelper, function(x){x$unit}),
                          "dimension" = sapply(aggSummary$metaDataHelper, function(x){x$dimension}))

knitr::kable(aggMetaData)

## ---- results='asis'----------------------------------------------------------
# Grouping by variable names:
grouping1 <- Grouping$new(c("Compound","Dose"))

## ---- results='asis'----------------------------------------------------------
# Grouping by variable names and overwriting the default label:
grouping2 <- Grouping$new(group = c("Compound","Dose"), label = "Compound & Dose")

## ---- results='asis'----------------------------------------------------------
# Grouping using a data.frame:
mappingDataFrame <- data.frame(Compound = c("Aspirin","Aspirin","Sugar","Sugar"),
                               Dose = c(6,3,6,3),  
                               "Compound & Dose"  = c("6mg of Aspirin",
                                                      "3mg of Aspirin",
                                                      "6mg of Sugar",
                                                      "3mg of Sugar"),
                               check.names = FALSE)
knitr::kable(mappingDataFrame)
grouping3 <- Grouping$new(group = mappingDataFrame)

## ---- results='asis'----------------------------------------------------------
# Apply the mapping to get the grouping captions:
groupingsDataFrame <- data.frame(timeProfileDataFrame$IndividualID,
                                 timeProfileDataFrame$Dose,
                                 timeProfileDataFrame$Compound,
                                 grouping1$getCaptions(timeProfileDataFrame),
                                 grouping2$getCaptions(timeProfileDataFrame),
                                 grouping3$getCaptions(timeProfileDataFrame))

names(groupingsDataFrame) <- c("IndividualID", "Dose", "Compound",
                               grouping1$label, grouping2$label, grouping3$label)

# Show results for all groupings:
knitr::kable(groupingsDataFrame)

## ---- results='asis'----------------------------------------------------------
# Grouping using a data.frame:
binningDataFrame <- data.frame(Age = I( list(c(0,6),c(7,100)) ), 
                               "Age Range" = c("Age 6 or lower",
                                               "Above age 6"),
                               check.names = FALSE)

## ---- results='asis'----------------------------------------------------------
grouping4 <- Grouping$new(group = binningDataFrame)

## ---- results='asis'----------------------------------------------------------
# Apply the mapping to get the grouping captions:
binnedGroupingsDataFrame <- data.frame(timeProfileDataFrame$IndividualID,
                                       timeProfileDataFrame$Age,
                                       grouping4$getCaptions(timeProfileDataFrame)) 

names(binnedGroupingsDataFrame) <- c("IndividualID", "Age", grouping4$label)

# Show results for all groupings:
knitr::kable(binnedGroupingsDataFrame)

## ---- results='asis'----------------------------------------------------------
# Map groups to aesthtic properties
groups1 <- GroupMapping$new(color =  grouping2 )

## ---- results='asis'----------------------------------------------------------
# Map groups to aesthtic properties
groups2 <- GroupMapping$new(color = c("Compound", "Dose"))

## ---- results='asis'----------------------------------------------------------
# Map groups to aesthtic properties
groups3 <- GroupMapping$new(color = Grouping$new(group = c("Compound", "Dose"),
                                                  label = c("Compound & Dose")))

## ---- results='asis'----------------------------------------------------------
tpMapping <- TimeProfileDataMapping$new(x="Time", y="Simulated")
knitr::kable(tpMapping$checkMapData(data = timeProfileDataFrame,
                                            metaData = timeProfileMetaData))

## ---- results='asis'----------------------------------------------------------
# Re-use the variable groups previously defined
tpMapping <- TimeProfileDataMapping$new(x="Time", y="Simulated", 
                                        groupMapping = groups1)

knitr::kable(tpMapping$checkMapData(data = timeProfileDataFrame))

## ---- result='as.is'----------------------------------------------------------
title <- Label$new(text = "This is a title text",
                   font = Font$new(color = "red",
                                   size = 12))

knitr::kable(data.frame("text" = title$text, 
           "color" = title$font$color,
           "size" = title$font$size,
           "face" = title$font$fontFace,
           "family" = title$font$fontFamily
           ))

## ---- result='as.is'----------------------------------------------------------
config <- PlotConfiguration$new()
tilteConfig <- config$title

knitr::kable(data.frame("text" = tilteConfig$text, 
           "color" = tilteConfig$font$color,
           "size" = tilteConfig$font$color,
           "face" = tilteConfig$font$fontFace,
           "family" = tilteConfig$font$fontFamily
           ))


## ---- result='as.is'----------------------------------------------------------
config <- PKRatioPlotConfiguration$new()
tilteConfig <- config$title

knitr::kable(data.frame("text" = tilteConfig$text, 
           "color" = tilteConfig$font$color,
           "size" = tilteConfig$font$color,
           "face" = tilteConfig$font$fontFace,
           "family" = tilteConfig$font$fontFamily
           ))


## ---- result='as.is'----------------------------------------------------------
background <- BackgroundConfiguration$new()

knitr::kable(data.frame("grid color" = background$grid$color, 
           "grid linetype" = background$grid$linetype, 
           "grid size" = background$grid$size))


## ---- results='as.is', echo=FALSE---------------------------------------------
knitr::kable(data.frame("Scaling" = as.character(sapply(Scaling, identity))))


## ---- results='as.is', echo=FALSE---------------------------------------------
knitr::kable(data.frame("LegendPositions" = as.character(sapply(LegendPositions, identity))))

## ---- results='as.is', echo=FALSE---------------------------------------------
legend <- LegendConfiguration$new()
# Currently color and fill have only 8 values, lintype 6 and shape and size 10.
# The following table will fill with "" the empty spaces
knitr::kable(data.frame("color" = c(legend$values$color, rep("",2)),
                        "fill" = c(legend$values$fill, rep("",2)),
                        "linetype" = c(legend$values$linetype, rep("",4)),
                        "shape" = legend$values$shape,
                        "size" = legend$values$size))

## -----------------------------------------------------------------------------
useTheme(tlfTheme)

## ---- fig.height=5, fig.width=7.5---------------------------------------------
# Input data and their metaData
data <- outputValues$data
metaData <- outputValues$metaData

variableNames <- names(data)

# Mapping x as Time, 8th variable of data as y and group the color by Gender
variableNames[8]

map <- TimeProfileDataMapping$new(x = "Time", 
                                  y = variableNames[8],
                                  color = "Gender")

# Define the default Theme
useTheme(tlfTheme)

# Define Y axis as a log scale
yAxis <- YAxisConfiguration$new(scale = Scaling$log10)

# By using metaData and dataMapping, the configuration get the label as dimension [unit] directly
config <- TimeProfilePlotConfiguration$new(title = "Minimal Example",
                                           yAxis = yAxis,
                                           data = data,
                                           metaData = metaData,
                                           dataMapping = map)

# Get the ggplot object
timeProfile <- plotTimeProfile(data = data,
                               metaData = metaData,
                               dataMapping = map,
                               plotConfiguration = config)
timeProfile

