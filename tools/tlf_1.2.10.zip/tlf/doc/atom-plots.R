## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  dpi = 300,
  fig.align = "center",
  out.width = "100%"
)

## ----setup--------------------------------------------------------------------
require(tlf)

## ----load-theme, echo=FALSE---------------------------------------------------
vignetteTheme <- loadThemeFromJson(system.file("extdata", "template-theme.json", package = "tlf"))
useTheme(vignetteTheme)

## ----initializePlot-----------------------------------------------------------
# Inintialize an empty plot without specific configuration, use the current theme
emptyPlot <- initializePlot()

# Create a PlotConfiguration object with some specifications
myConfiguration <- PlotConfiguration$new(
  title = "My empty plot",
  xlabel = "X",
  ylabel = "Y"
)

# Use the specification to create the plot
emptyPlotWithLabels <- initializePlot(myConfiguration)

# PlotConfiguration class has a smart mapping feature,
# directly deriving labels from data and its metaData and its dataMapping
time <- seq(0, 20, 0.1)
myData <- data.frame(
  x = time,
  y = 2 * cos(time)
)

# If metaData includes dimension and unit,
# they can be use by the smart configuration to generate labels as "dimension [unit]"
myMetaData <- list(
  x = list(
    dimension = "Time",
    unit = "min"
  ),
  y = list(
    dimension = "Amplitude",
    unit = "cm"
  )
)
myMapping <- XYGDataMapping$new(
  x = "x",
  y = "y"
)

# In this example, the configuration will use the x/y mapping from dataMapping
# to fetch dimension and unit from metaData
mySmartConfiguration <- PlotConfiguration$new(
  title = "My smart plot",
  data = myData,
  metaData = myMetaData,
  dataMapping = myMapping
)

smartEmptyPlot <- initializePlot(mySmartConfiguration)

## ----initializePlot-output, echo=FALSE, fig.cap="Left: emptyPlot; Middle: emptyPlotWithLabels; Right: smartEmptyPlot", fig.width=7.5----
gridExtra::grid.arrange(emptyPlot, emptyPlotWithLabels, smartEmptyPlot, ncol = 3)

## ----get-ExampleData, echo=FALSE----------------------------------------------
myTestData <- read.csv(system.file("extdata", "test-data.csv", package = "tlf"), stringsAsFactors = FALSE)
myTestData <- data.frame(
  x = myTestData$Obs,
  y = myTestData$Pred,
  type = myTestData$Sex,
  country = myTestData$Country
)

## ----show-ExampleData, results='asis'-----------------------------------------
knitr::kable(utils::head(myTestData))

## ----scatter-mapping----------------------------------------------------------
# Naive mapping on x and y
myMapping <- XYGDataMapping$new(
  x = "x",
  y = "y"
)

# Mapping on x and y, while grouping the data by type
myGroupMapping <- XYGDataMapping$new(
  x = "x",
  y = "y",
  color = "type"
)

# Plots

# Using the naive mapping
pNaive <- addScatter(
  data = myTestData,
  metaData = myMetaData,
  dataMapping = myMapping
)

# Using tlf smart mapping (same as naive)
pSmart <- addScatter(
  data = myTestData,
  metaData = myMetaData
)

# Using group in mapping
pGroup <- addScatter(
  data = myTestData,
  metaData = myMetaData,
  dataMapping = myGroupMapping
)

# Using x and y (same as naive but without metaData, no label)
pXY <- addScatter(
  x = myTestData$x,
  y = myTestData$y
)

## ----show-scatter-mapping, fig.height=7, fig.width=7, echo=FALSE, fig.cap="top left: pNaive; top right: pSmart; bottom left: pGroup; bottom right: pXY", fig.width=7.5----
gridExtra::grid.arrange(pNaive, pSmart, pGroup, pXY, ncol = 2)

## ----addScatter-options-------------------------------------------------------
males <- myTestData$type %in% "Male"
females <- myTestData$type %in% "Female"

# Using x and y
pScatter1 <- addScatter(
  x = myTestData$x[males],
  y = myTestData$y[males],
  color = "blue",
  size = 3,
  caption = "Male"
)
pScatter2 <- addScatter(
  x = myTestData$x[females],
  y = myTestData$y[females],
  color = "pink",
  size = 3,
  caption = "Female"
)
pScatter3 <- addScatter(
  x = myTestData$x[females],
  y = myTestData$y[females],
  color = "pink",
  size = 3,
  caption = "Female",
  plotObject = pScatter1
)

## ----show-addScatter, echo=FALSE, fig.width=9, fig.cap="Left: pScatter1; Middle: pScatter2; Right: pScatter3"----
gridExtra::grid.arrange(pScatter1, pScatter2, pScatter3, ncol = 3)

