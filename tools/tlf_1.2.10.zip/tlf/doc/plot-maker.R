## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
require(tlf)

## ----start-plot-maker, out.width="100%", include=TRUE, fig.align="center", echo=FALSE----
knitr::include_graphics("plot-maker/start-plot-maker.png")

## ----import-env-data, out.width="100%", include=TRUE, fig.align="center", echo=FALSE----
knitr::include_graphics("plot-maker/import-env-data.png")

## ----import-file-data, out.width="100%", include=TRUE, fig.align="center", echo=FALSE----
knitr::include_graphics("plot-maker/import-file-data.png")

## ----imported-data, out.width="100%", include=TRUE, fig.align="center", echo=FALSE----
knitr::include_graphics("plot-maker/imported-data.png")

## ----data-mapping, out.width="100%", include=TRUE, fig.align="center", echo=FALSE----
knitr::include_graphics("plot-maker/data-mapping.png")

## ----data-mapping-x, out.width="100%", include=TRUE, fig.align="center", echo=FALSE----
knitr::include_graphics("plot-maker/data-mapping-x.png")

## ----plot-selection, out.width="100%", include=TRUE, fig.align="center", echo=FALSE----
knitr::include_graphics("plot-maker/plot-selection.png")

## ----pk-ratio-plot, out.width="100%", include=TRUE, fig.align="center", echo=FALSE----
knitr::include_graphics("plot-maker/pk-ratio-plot.png")

## ----plot-labels, out.width="100%", include=TRUE, fig.align="center", echo=FALSE----
knitr::include_graphics("plot-maker/plot-labels.png")

## ----plot-background, out.width="100%", include=TRUE, fig.align="center", echo=FALSE----
knitr::include_graphics("plot-maker/plot-background.png")

## ----plot-axes, out.width="100%", include=TRUE, fig.align="center", echo=FALSE----
knitr::include_graphics("plot-maker/plot-axes.png")

## ----plot-legend, out.width="100%", include=TRUE, fig.align="center", echo=FALSE----
knitr::include_graphics("plot-maker/plot-legend.png")

## ----plot-aesthetics, out.width="100%", include=TRUE, fig.align="center", echo=FALSE----
knitr::include_graphics("plot-maker/plot-aesthetics.png")

## ----plot-export, out.width="100%", include=TRUE, fig.align="center", echo=FALSE----
knitr::include_graphics("plot-maker/plot-export.png")

## ----plot-regression, out.width="100%", include=TRUE, fig.align="center", echo=FALSE----
knitr::include_graphics("plot-maker/plot-regression.png")

## ----plot-tornado, out.width="100%", include=TRUE, fig.align="center", echo=FALSE----
knitr::include_graphics("plot-maker/plot-tornado.png")

