## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  dpi = 300,
  fig.align = "center",
  out.width = "100%",
  echo = FALSE
)

## ----setup--------------------------------------------------------------------
require(tlf)

## ----start-theme-maker--------------------------------------------------------
knitr::include_graphics("theme-maker/start-theme-maker.png")

## ----theme-labels-------------------------------------------------------------
knitr::include_graphics("theme-maker/labels.png")

## ----theme-background---------------------------------------------------------
knitr::include_graphics("theme-maker/background.png")

## ----theme-axes---------------------------------------------------------------
knitr::include_graphics("theme-maker/axes.png")

## ----theme-legend-------------------------------------------------------------
knitr::include_graphics("theme-maker/legend.png")

## ----sample-plots-------------------------------------------------------------
knitr::include_graphics("theme-maker/sample-plots.png")

## ----aes-map------------------------------------------------------------------
knitr::include_graphics("theme-maker/aes-map.png")

## ----aes-map-set--------------------------------------------------------------
knitr::include_graphics("theme-maker/aes-map-set.png")

## ----pk-ratio-color-----------------------------------------------------------
knitr::include_graphics("theme-maker/pk-ratio-color.png")

## ----pk-ratio-linetype--------------------------------------------------------
knitr::include_graphics("theme-maker/pk-ratio-linetype.png")

## ----pk-ratio-selection-key---------------------------------------------------
knitr::include_graphics("theme-maker/pk-ratio-selection-key.png")

## ----pk-ratio-linetype-next---------------------------------------------------
knitr::include_graphics("theme-maker/pk-ratio-linetype-next.png")

## ----save-theme---------------------------------------------------------------
knitr::include_graphics("theme-maker/save-theme.png")

## ----use-saved-theme----------------------------------------------------------
knitr::include_graphics("theme-maker/use-saved-theme.png")

