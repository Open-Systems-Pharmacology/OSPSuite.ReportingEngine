## -----------------------------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

library(tlf) 

dat <- read.csv("../data/results_from_PKSim.csv")

colnames(dat)<-c("IndividualId","Time","VenousBlood")
dat<-dat[dat$IndividualId %in% seq(1,6),1:3]
dat$IndividualId<-as.factor(dat$IndividualId)
stp<-cbind(dat[,1:2],Age=1,Gender="M",Population = "European",  Dose = 6 ,Compound = "Aspirin", dat[,3,drop=FALSE])

all_Age <- c(7,5,8,6,4,9)
all_Gender <- as.factor(c("M","F","M","F","M","M"))
all_Population <- as.factor(c("European","European","Asian","Asian","American","American"))
all_Dose <-  c(6,3,3,6,6,3) 
all_Compound <- as.factor(c("Aspirin","Sugar","Sugar","Sugar","Aspirin","Aspirin"))

levels(stp$Age) <- levels(all_Age)
levels(stp$Gender) <- levels(all_Gender)
levels(stp$Population) <- levels(all_Population)
levels(stp$Compound) <- levels(all_Compound) 

for (n in seq(1,6)){
  stp[stp$IndividualId==n,]$Age <- all_Age[n]
  stp[stp$IndividualId==n,]$Gender <- all_Gender[n]
  stp[stp$IndividualId==n,]$Population <- all_Population[n]
  stp[stp$IndividualId==n,]$Compound <- all_Compound[n]
  stp[stp$IndividualId==n,]$Dose <- all_Dose[n]
}

stp$IndividualId<-as.factor(stp$IndividualId)

## ---- out.width="100%", include=TRUE, fig.align="center", echo=FALSE----------
knitr::include_graphics("workflow.png")

## -----------------------------------------------------------------------------
minimalDataFrame <- data.frame("Time"=c(0,1,2,0,1,2),
                               "IndividualId"=as.factor(c(1,1,1,2,2,2)),
                               "Concentration"=c(3,4,5,4,5,6))

## ---- results='asis',echo=FALSE-----------------------------------------------
knitr::kable(minimalDataFrame, align='c')

## -----------------------------------------------------------------------------
minimalGrouping <- Grouping$new( group = "IndividualId" )

## ---- results='asis'----------------------------------------------------------
minimalDataMapping <- TimeProfileDataMapping$new(x = "Time",
                                                 y = "Concentration",
                                                 groupMapping = GroupMapping$new(linetype = minimalGrouping))

## ---- fig.height=5, fig.width=7.5---------------------------------------------
timeProfilePlot <- plotTimeProfile(data = minimalDataFrame, metaData = NULL, dataMapping = minimalDataMapping)
show(timeProfilePlot)

## ---- results='asis',echo=FALSE-----------------------------------------------
knitr::kable( rbind(
  stp[which(stp$IndividualId==1)[1],c("IndividualId","Time","Age","Gender","Population","Compound","Dose","VenousBlood")],
  stp[which(stp$IndividualId==2)[1],c("IndividualId","Time","Age","Gender","Population","Compound","Dose","VenousBlood")],
  stp[which(stp$IndividualId==3)[1],c("IndividualId","Time","Age","Gender","Population","Compound","Dose","VenousBlood")],
  stp[which(stp$IndividualId==4)[1],c("IndividualId","Time","Age","Gender","Population","Compound","Dose","VenousBlood")],
  stp[which(stp$IndividualId==5)[1],c("IndividualId","Time","Age","Gender","Population","Compound","Dose","VenousBlood")],
  stp[which(stp$IndividualId==6)[1],c("IndividualId","Time","Age","Gender","Population","Compound","Dose","VenousBlood")],
  stp[which(stp$IndividualId==1)[2],c("IndividualId","Time","Age","Gender","Population","Compound","Dose","VenousBlood")],
  stp[which(stp$IndividualId==2)[2],c("IndividualId","Time","Age","Gender","Population","Compound","Dose","VenousBlood")],
  stp[which(stp$IndividualId==3)[2],c("IndividualId","Time","Age","Gender","Population","Compound","Dose","VenousBlood")],
  stp[which(stp$IndividualId==4)[2],c("IndividualId","Time","Age","Gender","Population","Compound","Dose","VenousBlood")],
  stp[which(stp$IndividualId==5)[2],c("IndividualId","Time","Age","Gender","Population","Compound","Dose","VenousBlood")],
  stp[which(stp$IndividualId==6)[2],c("IndividualId","Time","Age","Gender","Population","Compound","Dose","VenousBlood")]) , row.names= FALSE , align='c' )

## ---- results='asis'----------------------------------------------------------
timeProfileMetaData<-list("Time"        =list(unit = "min",  dimension = "Time"         ),
                          "IndividualId"=list(unit = NULL,   dimension = NULL           ),
                          "Population"  =list(unit = NULL,   dimension = NULL           ),
                          "Gender"      =list(unit = NULL,   dimension = NULL           ),
                          "Age"         =list(unit = "yrs",  dimension = "Time"         ),
                          "Compound"    =list(unit = NULL,   dimension = NULL           ),
                          "Dose"        =list(unit = "mg",   dimension = "Amount"       ),
                          "Compartment" =list(unit = NULL,   dimension = NULL           ),
                          "VenousBlood" =list(unit = "mg/L", dimension = "Concentration")) 

## ---- results='asis'----------------------------------------------------------
aggSummary <- AggregationSummary$new(data = stp , 
                                     metaData = timeProfileMetaData,
                                     xColumnNames = "Time",
                                     groupingColumnNames = "Gender",
                                     yColumnNames = "VenousBlood",
                                     aggregationFunctionsVector = c(min,mean),
                                     aggregationFunctionNames =c("VenousBlood Min",
                                                                 "VenousBlood Mean"),
                                     aggregationUnitsVector = c("mg/L","mg/L"),
                                     aggregationDimensionsVector = c("Concentration",
                                                                     "Concentration"))

## ---- results='asis',echo=FALSE-----------------------------------------------
knitr::kable(head(aggSummary$dfHelper), digits=2, align='c') 

## ---- results='asis'----------------------------------------------------------
# Grouping by variable names:
grouping1 <- Grouping$new(c("Compound","Dose"))

## ---- results='asis'----------------------------------------------------------
# Grouping by variable names and overwriting the default label:
grouping2 <- Grouping$new(group = c("Compound","Dose"), label = "Compound & Dose")

## -----------------------------------------------------------------------------
# Grouping using a data.frame:
groupingDataFrame <- data.frame(Compound = c("Aspirin","Aspirin","Sugar","Sugar"),
                                Dose = c(6,3,6,3),  
                                "Compound & Dose" = c("6mg of Aspirin",
                                                      "3mg of Aspirin",
                                                      "6mg of Sugar",
                                                      "3mg of Sugar"),
                                check.names = FALSE)

## ---- results='asis',echo=FALSE-----------------------------------------------
knitr::kable(head(groupingDataFrame), align='c')
grouping3 <- Grouping$new(group = groupingDataFrame)

## -----------------------------------------------------------------------------

head(grouping3$getCaptions(stp))


## ---- results='asis',echo=FALSE-----------------------------------------------
# Apply the mapping to get the grouping captions:
groupingsDataFrame <- data.frame(stp$IndividualId,
                                 stp$Dose,
                                 stp$Compound,
                                 grouping1$getCaptions(stp),
                                 grouping2$getCaptions(stp),
                                 grouping3$getCaptions(stp))

names(groupingsDataFrame) <- c("IndividualId", "Dose", "Compound",
                               grouping1$label, grouping2$label, grouping3$label)

shortGroupingsDataFrame <-rbind( 
  groupingsDataFrame[groupingsDataFrame$IndividualId==1,][1,],
  groupingsDataFrame[groupingsDataFrame$IndividualId==2,][1,],
  groupingsDataFrame[groupingsDataFrame$IndividualId==3,][1,],
  groupingsDataFrame[groupingsDataFrame$IndividualId==4,][1,],
  groupingsDataFrame[groupingsDataFrame$IndividualId==5,][1,],
  groupingsDataFrame[groupingsDataFrame$IndividualId==6,][1,]  )


# Show results for all groupings:
knitr::kable(head(shortGroupingsDataFrame) , row.names = FALSE , align = 'c' ) 

## -----------------------------------------------------------------------------
# Grouping using a dataframe:
binningDataFrame <- data.frame(Age = I( list(c(0,6),c(7,100)) ), 
                               "Age Range" = c("Age 6 or lower",
                                               "Above age 6"),
                               check.names = FALSE)

## ---- results='asis',echo = FALSE---------------------------------------------
knitr::kable(binningDataFrame, align='c')
#pander::pandoc.table(  binningDataFrame )

## ---- results='asis'----------------------------------------------------------
grouping4 <- Grouping$new(group = binningDataFrame)

## ---- results='asis',echo=FALSE-----------------------------------------------
# Apply the mapping to get the grouping captions:
binnedGroupingsDataFrame <- data.frame(stp$IndividualId,
                                       stp$Age,
                                       grouping4$getCaptions(stp)) 

names(binnedGroupingsDataFrame) <- c("IndividualId", "Age", grouping4$label)

shortBinnedGroupingsDataFrame <-rbind( 
  binnedGroupingsDataFrame[binnedGroupingsDataFrame$IndividualId==1,][1,],
  binnedGroupingsDataFrame[binnedGroupingsDataFrame$IndividualId==2,][1,],
  binnedGroupingsDataFrame[binnedGroupingsDataFrame$IndividualId==3,][1,],
  binnedGroupingsDataFrame[binnedGroupingsDataFrame$IndividualId==4,][1,],
  binnedGroupingsDataFrame[binnedGroupingsDataFrame$IndividualId==5,][1,],
  binnedGroupingsDataFrame[binnedGroupingsDataFrame$IndividualId==6,][1,]  )

# Show results for all groupings:
knitr::kable(shortBinnedGroupingsDataFrame , row.names = FALSE, align='c') 

## ---- results='asis'----------------------------------------------------------
# Map groups to aesthtic properties
groups1 <- GroupMapping$new(color =  grouping2 )

## ---- results='asis'----------------------------------------------------------
# Map groups to aesthtic properties
groups2 <- GroupMapping$new(color = c("Compound", "Dose"))

## ---- results='asis'----------------------------------------------------------
# Map groups to aesthtic properties
groups3 <- GroupMapping$new(color = Grouping$new(group = c("Compound", "Dose"),
                                                 label = c("Compound & Dose")))

## ---- results='asis'----------------------------------------------------------
tpMapping <- TimeProfileDataMapping$new(x="Time", y="VenousBlood")
knitr::kable(head(tpMapping$checkMapData(data = stp,
                                         metaData = timeProfileMetaData)),
             row.names = FALSE,
             align='c')
# print(head(tpMapping$checkMapData(data = stp,
#                                          metaData = timeProfileMetaData)))


## ---- results='asis'----------------------------------------------------------
tpMapping <- TimeProfileDataMapping$new(x="Time", y="VenousBlood", 
                                        groupMapping = groups1)
knitr::kable(head(tpMapping$checkMapData(data = stp,
                                         metaData = timeProfileMetaData)),
             row.names = FALSE,
             align='c') 

## ---- results='asis'----------------------------------------------------------
# Use the helper to aggregate min and max values
hlp <- AggregationSummary$new(data = stp,
                              metaData = timeProfileMetaData,
                              xColumnNames = "Time",
                              groupingColumnNames = "Gender",
                              yColumnNames = "VenousBlood",
                              aggregationFunctionsVector = c(mean,min,max),
                              aggregationFunctionNames = c("VenousBlood Mean",
                                                           "VenousBlood Min",
                                                           "VenousBlood Max"),
                              aggregationUnitsVector = c("mg/L","mg/L","mg/L"),
                              aggregationDimensionsVector = c("Concentration",
                                                              "Concentration",
                                                              "Concentration"))


# Define Mapping with ymin and ymax
tpMapping <- TimeProfileDataMapping$new(x="Time", y="VenousBlood Mean", 
                                        ymin = "VenousBlood Min", ymax = "VenousBlood Max")
knitr::kable(head(tpMapping$checkMapData(data = hlp$dfHelper,
                                         metaData = hlp$metaDataHelper)) , align='c') 

## -----------------------------------------------------------------------------
config <- PlotConfiguration$new(title = "Title",
                                xlabel = "x-axis label", 
                                ylabel = "y-axis label", 
                                watermark = "background")

# Overall features of the configurtion
config

# Title and its configuration
config$title
config$title$font

# scale of x axis
config$xAxis$scale

## -----------------------------------------------------------------------------
tpConfig <- TimeProfilePlotConfiguration$new()

# Overall features of the configurtion
tpConfig

## -----------------------------------------------------------------------------
# Define the time profile mapping
tpMapping <- TimeProfileDataMapping$new(x="Time", y="VenousBlood")

# Define the time profile configuration using
# data, metaData and dataMapping
tpConfig <- TimeProfilePlotConfiguration$new(data = stp,
                                             metaData = timeProfileMetaData,
                                             dataMapping = tpMapping)

# Overall features of the configurtion
tpConfig

## ---- fig.height=5, fig.width=7.5---------------------------------------------
# Map x and y of the plot
tpMapping <- TimeProfileDataMapping$new(x="Time", y="VenousBlood")

# Define the ggplot object
plotObject <- plotTimeProfile(data=stp, 
                              metaData = timeProfileMetaData,
                              dataMapping = tpMapping)
# Show plot
plotObject


## ---- fig.height=5, fig.width=7.5---------------------------------------------
# Set current theme
useTheme(tlfTheme)

# Map x and y of the plot
tpMapping <- TimeProfileDataMapping$new(x="Time", y="VenousBlood")

# Overwrite plot configuration 
tpConfig <- TimeProfilePlotConfiguration$new(title = "New Plot",
                                             ylabel = "VenousBlood Results",
                                             data = stp,
                                             metaData = timeProfileMetaData,
                                             dataMapping = tpMapping)

# Define the ggplot object with updated configuration
plotObject <- plotTimeProfile(data=stp, 
                              metaData = timeProfileMetaData,
                              dataMapping = tpMapping, 
                              plotConfiguration = tpConfig)
# Show plot
plotObject


## ---- fig.height=5, fig.width=7.5---------------------------------------------
# Map x, y and groups of the plot
groups <- GroupMapping$new(color = "IndividualId", 
                           linetype = "Population")

tpMapping <- TimeProfileDataMapping$new(x = "Time", 
                                        y = "VenousBlood", 
                                        groupMapping = groups)

# Define the ggplot object
plotObject <- plotTimeProfile(data=stp,
                              metaData = timeProfileMetaData,
                              dataMapping = tpMapping)

# Show plot
plotObject


## ---- fig.height=5, fig.width=7.5---------------------------------------------
# data.frame associating grouping to Individual ID with their captions
groupingIndividualsDf <- data.frame(IndividualId = c(1,2,3,4,5,6) , 
                                    "Individual Name" = c("Paul", "John", "George", "Ringo","Mick","Freddie"),
                                    check.names = FALSE)
# Define the grouping variable
groups = GroupMapping$new(color = groupingIndividualsDf)

# Map x, y and groups
tpMapping <- TimeProfileDataMapping$new(x = "Time",
                                        y = "VenousBlood",
                                        groupMapping = groups)

# Define the ggplot object
plotObject <- plotTimeProfile(data=stp,
                              metaData = timeProfileMetaData,
                              dataMapping = tpMapping)

# Show plot
plotObject


## -----------------------------------------------------------------------------
print(levels(stp$IndividualId)) 

print(levels(groupingIndividualsDf$IndividualId))

## ---- fig.height=5, fig.width=7.5---------------------------------------------
# Define aggregated values through helper

hlp <- AggregationSummary$new(data = stp,
                              metaData = timeProfileMetaData,
                              xColumnNames = "Time",
                              groupingColumnNames = c("Population"),
                              yColumnNames = "VenousBlood",
                              aggregationFunctionsVector = c(mean,min,max),
                              aggregationFunctionNames = c("VenousBlood Mean",
                                                           "VenousBlood Min",
                                                           "VenousBlood Max"),
                              aggregationUnitsVector = c("mg/L","mg/L","mg/L"),
                              aggregationDimensionsVector = c("Concentration",
                                                              "Concentration",
                                                              "Concentration"))

# Map x and y
tpMappingMean <- TimeProfileDataMapping$new(x = "Time", 
                                            y = "VenousBlood Mean")
# Overwrite the plot configuration
tpConfig <-  TimeProfilePlotConfiguration$new(ylabel = "VenousBlood Results",
                                              xlabel = "Time")

# Define the ggplot object
meanPlot <- plotTimeProfile(data=hlp$dfHelper,
                            dataMapping = tpMappingMean,
                            plotConfiguration = tpConfig)
# Show plot
meanPlot

## ---- fig.height=5, fig.width=7.5---------------------------------------------
# Map x, y and groupings
tpMappingMean <- TimeProfileDataMapping$new(x = "Time", 
                                            y = "VenousBlood Mean",
                                            groupMapping = GroupMapping$new(color = "Population"))

# Overwrite the plot configuration
tpConfig <-  TimeProfilePlotConfiguration$new(ylabel = "VenousBlood Results",
                                              xlabel = "Time",
                                              data=hlp$dfHelper,
                                              dataMapping = tpMappingMean)

# Define the ggplot object
meanPlot <- plotTimeProfile(data=hlp$dfHelper,
                            dataMapping = tpMappingMean,
                            plotConfiguration = tpConfig)
# Show plot
meanPlot

## ---- fig.height=5, fig.width=7.5---------------------------------------------
# Map x, ymin and ymax
tpMappingRange <- TimeProfileDataMapping$new(x = "Time",
                                             ymin = "VenousBlood Min",
                                             ymax = "VenousBlood Max")

# Overwrite the plot configuration
tpConfig <-  TimeProfilePlotConfiguration$new(ylabel = "VenousBlood Results",
                                              xlabel = "Time",
                                              data=hlp$dfHelper,
                                              dataMapping = tpMappingRange)

# Define the ggplot object
rangePlot <- plotTimeProfile(data=hlp$dfHelper,
                             dataMapping = tpMappingRange)

# Show plot
rangePlot

## ---- fig.height=5, fig.width=7.5---------------------------------------------
# Map x, ymin and ymax
tpMappingRange <- TimeProfileDataMapping$new(x = "Time",
                                             ymin = "VenousBlood Min",
                                             ymax = "VenousBlood Max",
                                             groupMapping = GroupMapping$new(fill = "Population"))

# Overwrite the plot configuration
tpConfig <-  TimeProfilePlotConfiguration$new(ylabel = "VenousBlood Results",
                                              xlabel = "Time",
                                              data=hlp$dfHelper,
                                              dataMapping = tpMappingRange)

# Define the ggplot object
rangePlot <- plotTimeProfile(data=hlp$dfHelper,
                             dataMapping = tpMappingRange,
                             plotConfiguration = tpConfig)

# Show plot
rangePlot

## ---- fig.height=5, fig.width=7.5---------------------------------------------
# Map x, y, ymin and ymax
tpMappingErrorBar <- TimeProfileDataMapping$new(x = "Time", 
                                                y = "VenousBlood Mean",
                                                ymin = "VenousBlood Min", 
                                                ymax = "VenousBlood Max",
                                                groupMapping = GroupMapping$new(color = "Population"))

# Overwrite the plot configuration
tpConfig <-  TimeProfilePlotConfiguration$new(ylabel = "VenousBlood Results",
                                              xlabel = "Time",
                                              data=hlp$dfHelper,
                                              dataMapping = tpMappingErrorBar)

# Define the ggplot object
errorBarPlot <- plotTimeProfile(data=hlp$dfHelper,
                                dataMapping = tpMappingErrorBar,
                                plotConfiguration = tpConfig)

# Show plot
errorBarPlot


