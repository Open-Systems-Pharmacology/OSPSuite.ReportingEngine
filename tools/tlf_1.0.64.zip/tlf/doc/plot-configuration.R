## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(tlf)

## -----------------------------------------------------------------------------
myConfiguration <- PlotConfiguration$new()
# myConfiguration$print()

myConfiguration <- PlotConfiguration$new(title = "my title",
                                         watermark = "my watermark")
# myConfiguration$print()

## -----------------------------------------------------------------------------
emptyPlot <- initializePlot()

myEmptyPlot <- initializePlot(myConfiguration)

## ---- echo=FALSE, fig.cap="left: emptyPlot; right: myEmptyPlot", fig.width=7.5----
gridExtra::grid.arrange(emptyPlot, myEmptyPlot, ncol=2)

## -----------------------------------------------------------------------------
myEmptyLabel <- Label$new()
myEmptyLabel$print()

myLabel <- Label$new(text = "some text",
                     color = "blue")
myLabel$print()

## -----------------------------------------------------------------------------
myRedPlotLabel <- LabelConfiguration$new(title = Label$new(text = "my title", 
                                                           color = "red"))
myRedPlotLabel$title$print()
myRedPlotLabel$print()

myPlotLabel <- LabelConfiguration$new(title = "my title")
myPlotLabel$title$print()
myPlotLabel$print()

## -----------------------------------------------------------------------------
myConfiguration$labels$title$print()
myConfiguration$labels$print()

## -----------------------------------------------------------------------------
plotConfigurationLabel1 <- PlotConfiguration$new(title = "Title",
                                                     subtitle = "Subtitle",
                                                     xlabel = "x label",
                                                     ylabel = "y label")

pLab1 <- initializePlot(plotConfigurationLabel1)

plotConfigurationLabel2 <- PlotConfiguration$new(title = Label$new(text = "Title", size = 12, color = "deepskyblue4"),
                                                 subtitle = Label$new(text = "Subtitle", size = 11, color = "steelblue"),
                                                 xlabel = Label$new(text = "x label", size = 10, color = "dodgerblue2"),
                                                 ylabel = Label$new(text = "y label", size = 10, color = "dodgerblue2"))

pLab2 <- initializePlot(plotConfigurationLabel2)

## ---- echo=FALSE, fig.cap="left: pLab1; right: pLab2", fig.width=7.5----------
gridExtra::grid.arrange(pLab1, pLab2, ncol=2)

## -----------------------------------------------------------------------------
pLab2$plotConfiguration$labels$title$print()

pLab2Title <-  setPlotLabels(pLab2, title = "new title")
pLab2RedTitle <-  setPlotLabels(pLab2, title = Label$new(text = "new title", color = "red"))

pLab2Title$plotConfiguration$labels$title$print()
pLab2RedTitle$plotConfiguration$labels$title$print()

## ---- echo=FALSE, fig.cap="left: pLab2Title; right: pLab2RedTitle", fig.width=7.5----
gridExtra::grid.arrange(pLab2Title, pLab2RedTitle, ncol=2)

## -----------------------------------------------------------------------------
time <- seq(0,20, 0.1)
myData <- data.frame(x = time,
                     y = 2*cos(time))
myMetaData <- list(x = list(dimension = "Time",
                            unit = "min"),
                   y = list(dimension = "Amplitude",
                            unit = "cm"))
myMapping <- XYGDataMapping$new(x = "x",
                                y = "y")

smartConfig1 <- PlotConfiguration$new(data = myData)
smartConfig2 <- PlotConfiguration$new(data = myData,
                                      dataMapping = myMapping)
smartConfig3 <- PlotConfiguration$new(data = myData,
                                      metaData = myMetaData)
smartConfig4 <- PlotConfiguration$new(title = Label$new(text = "Cosinus", size = 14),
                                      ylabel = "Variations",
                                      data = myData,
                                      metaData = myMetaData)

pSmart1 <- initializePlot(smartConfig1) 
pSmart2 <- initializePlot(smartConfig2) 
pSmart3 <- initializePlot(smartConfig3) 
pSmart4 <- initializePlot(smartConfig4) 

## ---- echo=FALSE, fig.cap="left: pSmart1; right: pSmart2", fig.width=7.5------
gridExtra::grid.arrange(pSmart1, pSmart2, ncol=2)

## ---- echo=FALSE, fig.cap="left: pSmart3; right: pSmart4", fig.width=7.5------
gridExtra::grid.arrange(pSmart3, pSmart4, ncol=2)

## -----------------------------------------------------------------------------
scatter1 <-  addScatter(data = myData)
scatter2 <-  addScatter(data = myData,
                        metaData = myMetaData)

scatter3 <-  addScatter(data = myData,
                        plotConfiguration = smartConfig4)
scatter4 <- initializePlot(smartConfig4)
scatter4 <- addScatter(data = myData,
                       plotObject = scatter4)

## ---- echo=FALSE, fig.cap="left: scatter1; right: scatter2", fig.width=7.5----
gridExtra::grid.arrange(scatter1, scatter2, ncol=2)

## ---- echo=FALSE, fig.cap="left: scatter3; right: scatter4", fig.width=7.5----
gridExtra::grid.arrange(scatter3, scatter4, ncol=2)

## -----------------------------------------------------------------------------
myEmptyBackgroundConfiguration <- BackgroundConfiguration$new()
myEmptyBackgroundConfiguration$print()

## -----------------------------------------------------------------------------
plotConfigurationBackground1 <- PlotConfiguration$new(watermark = "My Watermark")

pBack1 <- initializePlot(plotConfigurationBackground1)

plotConfigurationBackground2 <- PlotConfiguration$new(
  watermark = Label$new(text = "Hello world", color = "goldenrod4", size = 8),
  background = BackgroundConfiguration$new(outerBackground = BackgroundElementConfiguration$new(fill = "lemonchiffon"),
                                           innerBackground = BackgroundElementConfiguration$new(fill = "lemonchiffon", 
                                                                                                color = "goldenrod3"),
                                           grid = BackgroundElementConfiguration$new(color = "goldenrod3")))

pBack2 <- initializePlot(plotConfigurationBackground2)

## ---- echo=FALSE, fig.cap="left: pBack1; right: pBack2", fig.width=7.5--------
gridExtra::grid.arrange(pBack1, pBack2, ncol=2)

## -----------------------------------------------------------------------------
scatter1$plotConfiguration$background$print()

scatterNewBackground1 <-  setBackground(scatter1, 
                             outerBackgroundFill = "darkolivegreen1",
                             fill = "darkolivegreen2",
                             color = "darkgreen",
                             linetype = "blank")
scatterNewBackground2 <-  setBackground(scatter1, 
                             outerBackgroundFill = "lemonchiffon",
                             fill = "lemonchiffon",
                             size = 2,
                             linetype = "solid")

scatterNewBackground1$plotConfiguration$background$print()
scatterNewBackground2$plotConfiguration$background$print()

## ---- echo=FALSE, fig.cap="top: scatter1; bottom left: scatterNewBackground1; bottom right: scatterNewBackground2", fig.width=7.5----
gridExtra::grid.arrange(grobs = list(scatter1, scatterNewBackground1, scatterNewBackground2), layout_matrix=rbind(c(1,1), c(2,3)))

## -----------------------------------------------------------------------------
scatterNewBackground1$plotConfiguration$background$grid$print()

# Remove grid
scatterNewGrid1 <-  setGrid(scatterNewBackground1, 
                             linetype = "blank")

scatterNewGrid1$plotConfiguration$background$grid$print()

scatterNewGrid2 <-  setGrid(scatterNewBackground2, 
                             color = "darkgreen",
                             size = 0.5,
                             linetype = "dotted")

scatterNewGrid2$plotConfiguration$background$grid$print()

## ---- echo=FALSE, fig.cap="left: scatterNewBackground1; right: scatterNewGrid1", fig.width=7.5----
gridExtra::grid.arrange(scatterNewBackground1, scatterNewGrid1, ncol=2)

## ---- echo=FALSE, fig.cap="left: scatterNewBackground2; right: scatterNewGrid2", fig.width=7.5----
gridExtra::grid.arrange(scatterNewBackground2, scatterNewGrid2, ncol=2)

## -----------------------------------------------------------------------------
pBack2$plotConfiguration$background$watermark$print()

pWatermark1 <-  setWatermark(pBack2, 
                            watermark = "Hi !!",
                            alpha = 1,
                            angle = 0)

pWatermark2 <-  setWatermark(pBack2,
                            alpha = 1,
                            angle = 45)

pWatermark1$plotConfiguration$background$watermark$print()
pWatermark2$plotConfiguration$background$watermark$print()

## -----------------------------------------------------------------------------
scatterNewGrid2$plotConfiguration$background$watermark$print()

scatterWatermark <-  setWatermark(scatterNewGrid2, 
                                  watermark = Label$new(text = "Confidential", color = "firebrick"))

scatterWatermark$plotConfiguration$background$watermark$print()

## ---- echo=FALSE, fig.cap="top: pBack2; bottom left: pWatermark2; bottom right: pWatermark2", fig.width=7.5----
gridExtra::grid.arrange(grobs = list(pBack2, pWatermark1, pWatermark2), layout_matrix = rbind(c(1,1),c(2,3)))

## ---- echo=FALSE, fig.cap="left: scatterNewGrid2; right: scatterWatermark", fig.width=7.5----
gridExtra::grid.arrange(scatterNewGrid2, scatterWatermark, ncol=2)

## -----------------------------------------------------------------------------
myEmptyAxisConfiguration <- XAxisConfiguration$new()
myEmptyAxisConfiguration$print()

myAxisConfiguration <- XAxisConfiguration$new(scale = Scaling$log10,
                                              limits = c(1, 100))
myAxisConfiguration$print()

## -----------------------------------------------------------------------------
scatter1$plotConfiguration$xAxis$print()
scatter1$plotConfiguration$yAxis$print()

scatterXlog <-  setXAxis(scatter1,
                          scale = Scaling$log10)

scatterXlog$plotConfiguration$xAxis$print()

scatterXTicks <-  setXAxis(scatter1,
                           limits = c(0, 6*pi),
                           ticks = seq(0, 6*pi, pi),
                           ticklabels = parse(text = c("0", "pi", paste0(seq(2, 6), "*pi"))))

scatterXTicks$plotConfiguration$xAxis$print()


## ---- echo=FALSE, fig.cap="top: scatter1; bottom left: scatterXlog; bottom right: scatterXTicks", fig.width=7.5----
gridExtra::grid.arrange(grobs = list(scatter1, scatterXlog, scatterXTicks), layout_matrix = rbind(c(1,1),c(2,3)))

## -----------------------------------------------------------------------------
myEmptyLegendConfiguration <- LegendConfiguration$new()
myEmptyLegendConfiguration$print()

myLegendConfiguration <- LegendConfiguration$new(title = "Legend Title",
                                                 position = LegendPositions$insideTopRight)
myLegendConfiguration$print()

## -----------------------------------------------------------------------------
plotConfigurationLegend1 <- PlotConfiguration$new()
plotConfigurationLegend1$legend$print()

emptyLegend1 <- initializePlot(plotConfigurationLegend1)
emptyLegend1$plotConfiguration$legend$print()

scatterLegend1 <- addScatter(data = myData,
                             plotConfiguration = plotConfigurationLegend1)
scatterLegend1$plotConfiguration$legend$print()

scatterLegend2 <- addLine(y = c(-1, 0, 1),
                          plotObject = scatterLegend1)
scatterLegend2$plotConfiguration$legend$print()

scatterLegend3 <- addScatter(data = myData,
                             caption = "Cosinus data",
                             color = "darkblue",
                             size = 2,
                             plotConfiguration = plotConfigurationLegend1)
scatterLegend3 <- addLine(y = c(-1, 0, 1),
                          caption = "Some lines",
                          color = "coral3",
                          linetype = "solid",
                          plotObject = scatterLegend3)
scatterLegend3$plotConfiguration$legend$print()

## ---- echo=FALSE, fig.cap="top left: emptyLegend1; top right: scatterLegend1; bottom left: scatterLegend2; bottom right: scatterLegend3", fig.width=7.5----
gridExtra::grid.arrange(emptyLegend1, scatterLegend1, scatterLegend2, scatterLegend3, ncol=2)

## -----------------------------------------------------------------------------
plotConfigurationLegend1 <- PlotConfiguration$new(legendTitle = "my legend",
                                                  legendPosition = LegendPositions$outsideTopLeft)
plotConfigurationLegend1$legend$print()

emptyLegend1 <- initializePlot(plotConfigurationLegend1)
emptyLegend1$plotConfiguration$legend$print()

scatterLegend1 <- addScatter(data = myData,
                             plotConfiguration = plotConfigurationLegend1)
scatterLegend1$plotConfiguration$legend$print()

scatterLegend2 <- addLine(y = c(-1, 0, 1),
                          plotObject = scatterLegend1)
scatterLegend2$plotConfiguration$legend$print()

scatterLegend3 <- addScatter(data = myData,
                             caption = "Cosinus data",
                             color = "darkblue",
                             size = 2,
                             plotConfiguration = plotConfigurationLegend1)
scatterLegend3 <- addLine(y = c(-1, 0, 1),
                          caption = "Some lines",
                          color = "coral3",
                          linetype = "solid",
                          plotObject = scatterLegend3)
scatterLegend3$plotConfiguration$legend$print()

## ---- echo=FALSE, fig.cap="top left: emptyLegend1; top right: scatterLegend1; bottom left: scatterLegend2; bottom right: scatterLegend3", fig.width=7.5----
gridExtra::grid.arrange(emptyLegend1, scatterLegend1, scatterLegend2, scatterLegend3, ncol=2)

## -----------------------------------------------------------------------------
scatterLegend3$legend$title

scatterLegend4<- setLegendTitle(scatterLegend3, "My new legend")
scatterLegend4$legend$title

## ---- echo=FALSE, fig.cap="left: scatterLegend3; right: scatterLegend4", fig.width=7.5----
gridExtra::grid.arrange(scatterLegend3, scatterLegend4, ncol=2)

## -----------------------------------------------------------------------------
scatterLegend3$legend$position

scatterLegend3Inside<- setLegendPosition(scatterLegend3, LegendPositions$insideTopRight)
scatterLegend3Inside$legend$position

## ---- echo=FALSE, fig.cap="left: scatterLegend3; right: scatterLegend3Inside", fig.width=7.5----
gridExtra::grid.arrange(scatterLegend3, scatterLegend3Inside, ncol=2)

