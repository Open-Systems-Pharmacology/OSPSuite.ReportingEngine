## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)
library(tlf)
useTheme(tlfTheme)

## ---- results='asis', echo=FALSE----------------------------------------------
tlfFunctionsTable <- data.frame("tlfStatFunctions" = as.character(sapply(tlfStatFunctions, identity)))

knitr::kable(tlfFunctionsTable)

## ---- results='asis'----------------------------------------------------------
# Load example
load("../data/pkRatioDataExample.RData")

# pkRatioData
knitr::kable(utils::head(pkRatioData), digits = 2)

# pkRatioMetaData is a list of variables contianing a lists with unit, dimension and lloq for each
# Unit and dimension of pkRatioData are consequently the following:
knitr::kable(data.frame(unit = t(rbind(sapply(pkRatioMetaData, function(x){x$unit}))),
                        dimension = t(rbind(sapply(pkRatioMetaData, function(x){x$dimension})))))

## ---- fig.height=5, fig.width=7.5---------------------------------------------
minMap <- BoxWhiskerDataMapping$new(y = "Age")

minBoxplot <- plotBoxWhisker(data = pkRatioData, 
                          metaData = pkRatioMetaData, 
                          dataMapping = minMap)
minBoxplot

## -----------------------------------------------------------------------------
xPopMap <- BoxWhiskerDataMapping$new(x = "Population",
                                     y = "Age")
xGenderMap <- BoxWhiskerDataMapping$new(x = "Gender",
                                        y = "Age")
fillPopMap <- BoxWhiskerDataMapping$new(y = "Age",
                                        fill = "Population")
fillGenderMap <- BoxWhiskerDataMapping$new(y = "Age",
                                           fill = "Gender")
xPopFillGenderMap <- BoxWhiskerDataMapping$new(x = "Population",
                                               y = "Age",
                                               fill = "Gender")
xGenderFillPopMap <- BoxWhiskerDataMapping$new(x = "Gender",
                                               y = "Age",
                                               fill = "Population")

xPopPlot <- plotBoxWhisker(data = pkRatioData,
                           metaData = pkRatioMetaData,
                           dataMapping = xPopMap)

xGenderPlot <- plotBoxWhisker(data = pkRatioData,
                              metaData = pkRatioMetaData,
                              dataMapping = xGenderMap)

fillPopPlot <- plotBoxWhisker(data = pkRatioData,
                              metaData = pkRatioMetaData,
                              dataMapping = fillPopMap)

fillGenderPlot <- plotBoxWhisker(data = pkRatioData,
                                 metaData = pkRatioMetaData,
                                 dataMapping = fillGenderMap)

xPopFillGenderPlot <- plotBoxWhisker(data = pkRatioData,
                                        metaData = pkRatioMetaData,
                                        dataMapping = xPopFillGenderMap)

xGenderFillPopPlot <- plotBoxWhisker(data = pkRatioData,
                                        metaData = pkRatioMetaData,
                                        dataMapping = xGenderFillPopMap)


## ---- fig.height=5, fig.width=7.5, fig.cap="Boxplot mapping Population as x"----
xPopPlot

## ---- fig.height=5, fig.width=7.5, fig.cap="Boxplot mapping Gender as x"------
xGenderPlot

## ---- fig.height=5, fig.width=7.5, fig.cap="Boxplot mapping Population as fill"----
fillPopPlot

## ---- fig.height=5, fig.width=7.5, fig.cap="Boxplot mapping Gender as fill"----
fillGenderPlot

## ---- fig.height=5, fig.width=7.5, fig.cap="Boxplot mapping Population as x and Gender as fill"----
xPopFillGenderPlot

## ---- fig.height=5, fig.width=7.5, fig.cap="Boxplot mapping Gender as x and Population as fill"----
xGenderFillPopPlot

## ---- fig.height=5, fig.width=7.5, fig.cap="Boxplot mapping Population as x, Gender as fill and assuming normal distribution"----

normMap <- BoxWhiskerDataMapping$new(x = "Population",
                                     y = "Age",
                                     fill = "Gender",
                                     ymin = tlfStatFunctions$`mean-1.96sd`,
                                     middle = tlfStatFunctions$mean,
                                     ymax = tlfStatFunctions$`mean+1.96sd`)

normBoxplot <- plotBoxWhisker(data = pkRatioData,
                              metaData = pkRatioMetaData,
                              dataMapping = normMap)
normBoxplot

## ---- fig.height=5, fig.width=7.5, fig.cap="Boxplot mapping Population as x, Gender as fill and assuming normal distribution"----

normMap2 <- BoxWhiskerDataMapping$new(x = "Population",
                                     y = "Age",
                                     fill = "Gender",
                                     ymin = tlfStatFunctions$`mean-1.96sd`,
                                     lower = tlfStatFunctions$`mean-sd`,
                                     middle = tlfStatFunctions$mean,
                                     upper = tlfStatFunctions$`mean+sd`,
                                     ymax = tlfStatFunctions$`mean+1.96sd`)

normBoxplot2 <- plotBoxWhisker(data = pkRatioData,
                              metaData = pkRatioMetaData,
                              dataMapping = normMap2)
normBoxplot2

## ---- fig.height=5, fig.width=7.5, fig.cap="Boxplot mapping Population as x, Gender as fill and assuming normal distribution"----

outlierMap <- BoxWhiskerDataMapping$new(x = "Population",
                                        y = "Age",
                                        fill = "Gender",
                                        ymin = tlfStatFunctions$`Percentile10%`,
                                        ymax = tlfStatFunctions$`Percentile90%`,
                                        minOutlierLimit = tlfStatFunctions$`Percentile10%`,
                                        maxOutlierLimit = tlfStatFunctions$`Percentile90%`)

outlierBoxplot <- plotBoxWhisker(data = pkRatioData,
                              metaData = pkRatioMetaData,
                              dataMapping = outlierMap)
outlierBoxplot

## ---- results='as.is'---------------------------------------------------------
boxplotSummary <- outlierMap$getBoxWhiskerLimits(pkRatioData)

knitr::kable(boxplotSummary, digits = 2)

## ---- results='as.is'---------------------------------------------------------
outliers <- outlierMap$getOutliers(pkRatioData)
outliers <- outliers[, c("Age", "minOutlierLimit", "maxOutlierLimit", "minOutliers", "maxOutliers")]

knitr::kable(outliers, digits = 2)

