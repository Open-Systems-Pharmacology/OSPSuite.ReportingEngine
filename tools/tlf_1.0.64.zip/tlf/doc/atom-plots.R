## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(tlf)

## -----------------------------------------------------------------------------
# No specific configuration
emptyPlot <- initializePlot()

# PlotConfiguration
myConfiguration <- PlotConfiguration$new(title = "My empty plot",
                                         xlabel = "X",
                                         ylabel = "Y")
emptyPlotWithLabels <- initializePlot(myConfiguration)

# Smart PlotConfiguration
time <- seq(0,20, 0.1)
myData <- data.frame(x = time,
                     y = 2*cos(time))
myMetaData <- list(x = list(dimension = "Time",
                            unit = "min"),
                   y = list(dimension = "Amplitude",
                            unit = "cm"))
myMapping <- XYGDataMapping$new(x = "x",
                                y = "y")

mySmartConfiguration <- PlotConfiguration$new(title = "My smart plot",
                                              data = myData,
                                              metaData = myMetaData,
                                              dataMapping = myMapping)

smartEmptyPlot <- initializePlot(mySmartConfiguration)

# Using another theme to change default
useTheme(tlfTheme)
myNewSmartConfiguration <- PlotConfiguration$new(title = "My smart plot",
                                              data = myData,
                                              metaData = myMetaData,
                                              dataMapping = myMapping)
smartEmptyPlotNewTheme <- initializePlot(myNewSmartConfiguration)

## ---- echo=FALSE--------------------------------------------------------------
useTheme(defaultTheme)

## ---- echo=FALSE, fig.cap="top left: emptyPlot; top right: emptyPlotWithLabels; bottom left: smartEmptyPlot; bottom right: ", fig.width=7.5----
gridExtra::grid.arrange(emptyPlot, emptyPlotWithLabels, smartEmptyPlot, smartEmptyPlotNewTheme, ncol=2)

## -----------------------------------------------------------------------------
myCosData <- rbind.data.frame(data.frame(x = time,
                                         y = 2*cos(time),
                                         type = "cosinus"),
                              data.frame(x = time,
                                         y = 2*sin(time),
                                         type = "sinus"),
                              data.frame(x = time,
                                         y = round(2*sin(time)),
                                         type = "stairs"))

## -----------------------------------------------------------------------------
# Naive mapping on x and y
myMapping <- XYGDataMapping$new(x = "x",
                                y = "y")

# Mapping on x and y, while grouping the data by type
myGroupMapping <- XYGDataMapping$new(x = "x",
                                     y = "y",
                                     color = "type")
# Using the naive mapping
pNaive <- addScatter(data = myCosData,
                     metaData = myMetaData,
                     dataMapping = myMapping)

# Using tlf smart mapping (same as naive)
pSmart <- addScatter(data = myCosData,
                     metaData = myMetaData)

# Using group in mapping
pGroup <- addScatter(data = myCosData,
                metaData = myMetaData,
                dataMapping = myGroupMapping)

# Using x and y (same as naive but without metaData, no label)
pXY <- addScatter(x = myCosData$x,
                  y = myCosData$y)

## ---- echo=FALSE, fig.cap="top left: pNaive; top right: pSmart; bottom left: pGroup; bottom right: pXY", fig.width=7.5----
gridExtra::grid.arrange(pNaive, pSmart, pGroup, pXY, ncol=2)

## -----------------------------------------------------------------------------
# Using x and y
pScatter1 <- addScatter(x = myCosData$x[myCosData$type %in% "cosinus"],
                  y = myCosData$y[myCosData$type %in% "cosinus"])



## ---- echo=FALSE, fig.cap="top left: pNaive; top right: pSmart; bottom left: pGroup; bottom right: pXY", fig.width=7.5----
gridExtra::grid.arrange(pScatter1, pScatter1, pScatter1, pScatter1, ncol=2)

## -----------------------------------------------------------------------------

line1 <- addLine(data = myCosData[myCosData$type %in% "cosinus",],
                 metaData = myMetaData,
                 dataMapping = myMapping,
                 caption = "cosinus")
# y intercepts
line2 <- addLine(y = c(-2,0,2),
                 caption = "y-intercepts",
                 color = "darkblue",
                 size = 2,
                 linetype = "longdash",
                 plotObject = line1)

line3 <- addLine(data = myCosData,
                 metaData = myMetaData,
                 dataMapping = myGroupMapping)

line4 <- addLine(x = seq(0, 5*pi, pi),
                 y = rep(c(-1, 1), 3),
                 caption = "frame",
                 color = "brown4",
                 linetype = "solid",
                 plotObject = line3)


## ---- echo=FALSE, fig.cap="top left: line1; top right: line2; bottom left: line3; bottom right: line4", fig.width=7.5----
gridExtra::grid.arrange(line1, line2, line3, line4, ncol=2)

