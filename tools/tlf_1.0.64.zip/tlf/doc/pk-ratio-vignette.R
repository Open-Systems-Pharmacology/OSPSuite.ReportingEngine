## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)
library(tlf)

## ---- results='asis'----------------------------------------------------------
# Load example
load("../data/pkRatioDataExample.RData")

# pkRatioData
knitr::kable(utils::head(pkRatioData), digits = 2)

# pkRatioMetaData is a list of variables contianing a lists with unit, dimension and lloq for each
# Unit and dimension of pkRatioData are consequently the following:
knitr::kable(data.frame(unit = t(rbind(sapply(pkRatioMetaData, function(x){x$unit}))),
                        dimension = t(rbind(sapply(pkRatioMetaData, function(x){x$dimension})))))

## ---- fig.height=5, fig.width=7.5---------------------------------------------
plotPKRatio(data = pkRatioData[,c("Age", "Ratio")])

## -----------------------------------------------------------------------------
# Two-step process
colorMapping <- GroupMapping$new(color = "Gender")
dataMappingA <- PKRatioDataMapping$new(x = "Age", 
                                      y = "Ratio", 
                                      groupMapping = colorMapping)

print(dataMappingA$groupMapping$color$label)

# One-step process
dataMappingB <- PKRatioDataMapping$new(x = "Age", 
                                      y = "Ratio", 
                                      color = "Gender")

print(dataMappingB$groupMapping$color$label)


## ---- fig.height=5, fig.width=7.5---------------------------------------------
plotPKRatio(data = pkRatioData, 
            dataMapping = dataMappingB)

## ---- fig.height=5, fig.width=7.5---------------------------------------------
dataMapping2groups <- PKRatioDataMapping$new(x = "Age",
                                             y = "Ratio",
                                             color = "Gender",
                                             shape = c("Dose", "Compound"))
plotPKRatio(data = pkRatioData, 
            dataMapping = dataMapping2groups)

## ---- echo=FALSE, results='asis'----------------------------------------------
groupDataFrame <- data.frame(Dose = c(50, 100, 50, 100, 50, 100, 50, 100), 
                             Compound = c("Aspirin", "Aspirin", "Vancomycin", "Vancomycin", "Aspirin", "Aspirin", "Vancomycin", "Vancomycin"),
                             Gender = c("M", "M", "M", "M", "F", "F", "F", "F"),
                             Group = c("Males infused with 50mg of Aspirin", "Males infused with 100mg of Aspirin", 
                                       "Males infused with 50mg of Vancomycin", "Males infused with 100mg of Vancomycin",
                                       "Females infused with 50mg of Aspirin",  "Females infused with 100mg of Aspirin", 
                                       "Females infused with 50mg of Vancomycin", "Females infused with 100mg of Vancomycin"))
knitr::kable(groupDataFrame)

## ---- fig.height=5, fig.width=7.5---------------------------------------------
dataMappingDF <- PKRatioDataMapping$new(x = "Age",
                                             y = "Ratio",
                                             color = groupDataFrame,
                                             shape = groupDataFrame)
plotPKRatio(data = pkRatioData, 
            dataMapping = dataMappingDF)

## -----------------------------------------------------------------------------
linesMapping <- PKRatioDataMapping$new()
linesMapping$pkRatioValues

## ---- fig.height=5, fig.width=7.5---------------------------------------------
linesMapping <- PKRatioDataMapping$new(pkRatioValues = list(pkRatioLine1 = 1, pkRatioLine2 = c(0.2, 5)),
                                       x = "Age", 
                                       y = "Ratio",
                                       color = "Gender")
plotPKRatio(data = pkRatioData, 
            dataMapping = linesMapping)


## ---- fig.height=5, fig.width=7.5---------------------------------------------
useTheme(bwTheme)
plotPKRatio(data = pkRatioData[,c("Age", "Ratio")])

## ---- fig.height=5, fig.width=7.5---------------------------------------------
useTheme(tlfTheme)
plotPKRatio(data = pkRatioData[,c("Age", "Ratio")])

## ---- fig.height=5, fig.width=7.5---------------------------------------------
labelConfiguration <- PKRatioPlotConfiguration$new(title = "New Title",
                                                   subtitle = "New subtitle",
                                                   xlabel = "New X-axis",
                                                   ylabel = "New Y-axis")
plotPKRatio(data = pkRatioData[,c("Age", "Ratio")],
            plotConfiguration = labelConfiguration)

## ---- fig.height=5, fig.width=7.5---------------------------------------------
labelConfiguration1 <- PKRatioPlotConfiguration$new(title = Label$new(text = "Title as Label", 
                                                                     font = Font$new(color = "red")))
labelConfiguration2 <- PKRatioPlotConfiguration$new(title = "Title as Label")
labelConfiguration2$labels$title$font$color <- "red"

isTRUE(labelConfiguration1$labels$title$font$color == labelConfiguration2$labels$title$font$color)

## ---- results='asis'----------------------------------------------------------
# Test of getPKRatioMeasure
PKRatioMeasure <- getPKRatioMeasure(data = pkRatioData[,c("Age", "Ratio")])

knitr::kable(x = PKRatioMeasure,
             caption = "Qualification of PK Ratios")

## -----------------------------------------------------------------------------
linesMapping <- DDIRatioDataMapping$new()

## ---- fig.height=5, fig.width=7.5---------------------------------------------
useTheme(tlfTheme)

# Process data
pkRatioData$Observed <- pkRatioData$Observed/10
pkRatioData$Simulated <- pkRatioData$Simulated/10

# Define Mapping
ddiMapping <- DDIRatioDataMapping$new(x = "Observed",
                                      y = "Simulated",
                                      color = "Gender",
                                      shape = c("Dose", "Compound"))
# Define configuration
ddiConfiguration <- DDIRatioPlotConfiguration$new(xlabel = "Obs",
                                                  ylabel = "Pred",
                                                  data = pkRatioData,
                                                  metaData = pkRatioMetaData,
                                                  dataMapping = ddiMapping)
# Plot
plotDDIRatio(data = pkRatioData,
             metaData = pkRatioMetaData,
             dataMapping = ddiMapping,
             plotConfiguration = ddiConfiguration)

