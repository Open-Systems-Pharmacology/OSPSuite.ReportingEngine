## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
require(tlf)

## ----load theme, echo=FALSE---------------------------------------------------
vignetteTheme <- loadThemeFromJson(system.file("extdata", "template-theme.json", package = "tlf"))
useTheme(vignetteTheme)

## ----empty configuration plots------------------------------------------------
myConfiguration <- PlotConfiguration$new()
# myConfiguration$print()

myConfiguration <- PlotConfiguration$new(title = "my title",
                                         watermark = "my watermark")
# myConfiguration$print()

## ----empty plots--------------------------------------------------------------
emptyPlot <- initializePlot()

myEmptyPlot <- initializePlot(myConfiguration)

## ----show empty plots, echo=FALSE, fig.cap="left: emptyPlot; right: myEmptyPlot", fig.width=7.5----
gridExtra::grid.arrange(emptyPlot, myEmptyPlot, ncol=2)

## ----label example------------------------------------------------------------
title <- Label$new(text = "This is a title text",
                   font = Font$new(color = "red",
                                   size = 12))

## ----show label example, results='asis', echo=FALSE---------------------------
knitr::kable(data.frame("text" = title$text, 
           "color" = title$font$color,
           "size" = title$font$size,
           "face" = title$font$fontFace,
           "family" = title$font$fontFamily,
           "angle" = title$font$angle
           ))

## ----label configuration------------------------------------------------------
myRedPlotLabel <- LabelConfiguration$new(title = Label$new(text = "my title", 
                                                           color = "red"))

## ----show label configuration, results='asis', echo=FALSE---------------------
knitr::kable(
  data.frame(
    Property = c("text", "color", "size", "angle", "fontFace", "fontFamily"),
    title = c(myRedPlotLabel$title$text, myRedPlotLabel$title$font$color, myRedPlotLabel$title$font$size, 
              myRedPlotLabel$title$font$angle, myRedPlotLabel$title$font$fontFace, myRedPlotLabel$title$font$fontFamily),
    subtitle = c("", myRedPlotLabel$subtitle$font$color, myRedPlotLabel$subtitle$font$size, 
                 myRedPlotLabel$subtitle$font$angle, myRedPlotLabel$subtitle$font$fontFace, myRedPlotLabel$subtitle$font$fontFamily),
    xlabel = c("", myRedPlotLabel$xlabel$font$color, myRedPlotLabel$xlabel$font$size, 
               myRedPlotLabel$xlabel$font$angle, myRedPlotLabel$xlabel$font$fontFace, myRedPlotLabel$xlabel$font$fontFamily),
    ylabel = c("", myRedPlotLabel$ylabel$font$color, myRedPlotLabel$ylabel$font$size, 
               myRedPlotLabel$ylabel$font$angle, myRedPlotLabel$ylabel$font$fontFace, myRedPlotLabel$ylabel$font$fontFamily)
    )
  )

## ----label in plot configuration----------------------------------------------
plotConfigurationLabel1 <- PlotConfiguration$new(title = "Title",
                                                     subtitle = "Subtitle",
                                                     xlabel = "x label",
                                                     ylabel = "y label")

pLab1 <- initializePlot(plotConfigurationLabel1)

plotConfigurationLabel2 <- PlotConfiguration$new(title = Label$new(text = "Title", size = 12, color = "deepskyblue4"),
                                                 subtitle = Label$new(text = "Subtitle", size = 11, color = "steelblue"),
                                                 xlabel = Label$new(text = "x label", size = 10, color = "dodgerblue2"),
                                                 ylabel = Label$new(text = "y label", size = 10, color = "dodgerblue2"))

pLab2 <- initializePlot(plotConfigurationLabel2)

## ----show label in plot configuration, echo=FALSE, fig.cap="left: pLab1; right: pLab2", fig.width=7.5----
gridExtra::grid.arrange(pLab1, pLab2, ncol=2)

## ----set new title, fig.width=7.5---------------------------------------------
setPlotLabels(pLab2, title = "new title")

## ----set new redtitle, fig.width=7.5------------------------------------------
setPlotLabels(pLab2, title = Label$new(text = "new title", color = "red"))

## ----smart example------------------------------------------------------------
time <- seq(0,20, 0.1)
myData <- data.frame(x = time,
                     y = 2*cos(time))
myMetaData <- list(x = list(dimension = "Time",
                            unit = "min"),
                   y = list(dimension = "Amplitude",
                            unit = "cm"))
myMapping <- XYGDataMapping$new(x = "x",
                                y = "y")

smartConfig1 <- PlotConfiguration$new(data = myData)
smartConfig2 <- PlotConfiguration$new(data = myData,
                                      dataMapping = myMapping)
smartConfig3 <- PlotConfiguration$new(data = myData,
                                      metaData = myMetaData)
smartConfig4 <- PlotConfiguration$new(title = Label$new(text = "Cosinus", size = 14),
                                      ylabel = "Variations",
                                      data = myData,
                                      metaData = myMetaData)

pSmart1 <- initializePlot(smartConfig1) 
pSmart2 <- initializePlot(smartConfig2) 
pSmart3 <- initializePlot(smartConfig3) 
pSmart4 <- initializePlot(smartConfig4) 

## ----show smart example 1, echo=FALSE, fig.cap="left: pSmart1; right: pSmart2", fig.width=7.5----
gridExtra::grid.arrange(pSmart1, pSmart2, ncol=2)

## ----show smart example 2, echo=FALSE, fig.cap="left: pSmart3; right: pSmart4", fig.width=7.5----
gridExtra::grid.arrange(pSmart3, pSmart4, ncol=2)

## ----smart sccatter-----------------------------------------------------------
scatter1 <-  addScatter(data = myData)
scatter2 <-  addScatter(data = myData,
                        metaData = myMetaData)

scatter3 <-  addScatter(data = myData,
                        plotConfiguration = smartConfig4)
scatter4 <- initializePlot(smartConfig4)
scatter4 <- addScatter(data = myData,
                       plotObject = scatter4)

## ----show smart scatter 1, echo=FALSE, fig.cap="left: scatter1; right: scatter2", fig.width=7.5----
gridExtra::grid.arrange(scatter1, scatter2, ncol=2)

## ----show smart scatter 2, echo=FALSE, fig.cap="left: scatter3; right: scatter4", fig.width=7.5----
gridExtra::grid.arrange(scatter3, scatter4, ncol=2)

## ----background object, result='as.is'----------------------------------------
background <- BackgroundConfiguration$new()

knitr::kable(
  data.frame(Property = c("color", "size", "linetype", "fill"),
             plot = c(background$plot$color, background$plot$size, background$plot$linetype, background$plot$fill),
             panel = c(background$panel$color, background$panel$size, background$panel$linetype, background$panel$fill),
             xGrid = c(background$xGrid$color, background$xGrid$size, background$xGrid$linetype, ""),
             yGrid = c(background$yGrid$color, background$yGrid$size, background$yGrid$linetype, ""),
             xAxis = c(background$xAxis$color, background$xAxis$size, background$xAxis$linetype, ""),
             yAxis = c(background$yAxis$color, background$yAxis$size, background$yAxis$linetype, "")
             )
  )


## ----background in plot configuration-----------------------------------------
plotConfigurationBackground1 <- PlotConfiguration$new(watermark = "My Watermark")

pBack1 <- initializePlot(plotConfigurationBackground1)

plotConfigurationBackground1$background$watermark <- Label$new(text = "Hello world", color = "goldenrod4", size = 8)
plotConfigurationBackground1$background$plot <- BackgroundElement$new(fill = "lemonchiffon", color = "goldenrod3", linetype = "solid")
plotConfigurationBackground1$background$panel <- BackgroundElement$new(fill = "grey", color = "black", linetype = "solid")
pBack2 <- initializePlot(plotConfigurationBackground1)

## ----show background in plot configuration, echo=FALSE, fig.cap="left: pBack1; right: pBack2", fig.width=7.5----
gridExtra::grid.arrange(pBack1, pBack2, ncol=2)

## ----set plot background 1, fig.width=7.5-------------------------------------
setBackground(scatter1, fill = "lemonchiffon", color = "darkgreen", linetype = "solid")

## ----set panel background 1, fig.width=7.5------------------------------------
setBackgroundPanelArea(scatter1, fill = "lemonchiffon", color = "darkgreen", linetype = "solid")

## ----set plot grid 1, fig.width=7.5-------------------------------------------
setGrid(scatter1, linetype = "blank")

## ----set plot y grid, fig.width=7.5-------------------------------------------
setXGrid(scatter1, linetype = "blank")

## ----set watermark 1, fig.width=7.5-------------------------------------------
setWatermark(scatter1, watermark = "Hello watermark !!")

## ----set watermark 2, fig.width=7.5-------------------------------------------
setWatermark(scatter1, watermark = "Confidential", angle = 45, size = 6, color = "firebrick")

## ----define axis--------------------------------------------------------------
myAxisConfiguration <- XAxisConfiguration$new()

myAxisConfiguration$scale
myAxisConfiguration$ticklabels

## ----set x axis, fig.width=7.5------------------------------------------------
setXAxis(scatter1, limits = c(0.5, 20), scale = Scaling$sqrt)

## ----set x axis ticks, fig.width=7.5------------------------------------------
setXAxis(scatter1, 
         limits = c(0, 6*pi),
         ticks = seq(0, 6*pi, pi),
         ticklabels = c("0", "pi", paste0(seq(2, 6), "*pi")),
         font = Font$new(color = "dodgerblue"))

## ----legend configuration-----------------------------------------------------
myLegend <- LegendConfiguration$new(position = LegendPositions$insideTopRight)

## ----legend position, fig.width=7.5-------------------------------------------
setLegendPosition(scatter1, LegendPositions$insideTopLeft)

