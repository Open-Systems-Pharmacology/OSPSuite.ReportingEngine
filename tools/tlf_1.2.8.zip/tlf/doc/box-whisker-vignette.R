## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
require(tlf)

## ----load theme, echo=FALSE---------------------------------------------------
vignetteTheme <- loadThemeFromJson(system.file("extdata", "template-theme.json", package = "tlf"))
useTheme(vignetteTheme)

## ----load data, results='asis'------------------------------------------------
# Load example
pkRatioData <- read.csv(system.file("extdata", "test-data.csv", package = "tlf"), stringsAsFactors = FALSE)

# pkRatioData
knitr::kable(utils::head(pkRatioData), digits = 2)

## ----load metadata, echo=FALSE------------------------------------------------
# Load example
pkRatioMetaData <- list(Age = list(dimension = "Age",
                                   unit = "yrs"),
                        Obs = list(dimension = "Clearance",
                                   unit = "dL/h/kg"),
                        Pred = list(dimension = "Clearance",
                                    unit = "dL/h/kg"),
                        Ratio = list(dimension = "Ratio",
                                     unit = "")
                        )

## ----show metadata, results='asis'--------------------------------------------
knitr::kable(data.frame(Variable = c("Age", "Obs", "Pred", "Ratio"),
                        Dimension = c("Age", "Clearance", "Clearance", "Ratio"),
                        Unit = c("yrs", "dL/h/kg", "dL/h/kg", "")))

## ----minimal example, fig.height=5, fig.width=7.5-----------------------------
minMap <- BoxWhiskerDataMapping$new(y = "Age")

minBoxplot <- plotBoxWhisker(data = pkRatioData, 
                          metaData = pkRatioMetaData, 
                          dataMapping = minMap)
minBoxplot

## ----difference x vs fill-----------------------------------------------------
xPopMap <- BoxWhiskerDataMapping$new(x = "Country",
                                     y = "Age")

xSexMap <- BoxWhiskerDataMapping$new(x = "Sex",
                                     y = "Age")

fillPopMap <- BoxWhiskerDataMapping$new(y = "Age",
                                        fill = "Country")

fillSexMap <- BoxWhiskerDataMapping$new(y = "Age",
                                        fill = "Sex")
xPopFillSexMap <- BoxWhiskerDataMapping$new(x = "Country",
                                            y = "Age",
                                            fill = "Sex")

xSexFillPopMap <- BoxWhiskerDataMapping$new(x = "Sex",
                                            y = "Age",
                                            fill = "Country")

## ----boxplot country x, fig.height=5, fig.width=7.5, fig.cap="Boxplot mapping Country as x"----
plotBoxWhisker(data = pkRatioData,
               metaData = pkRatioMetaData,
               dataMapping = xPopMap)

## ----boxplot sex x, fig.height=5, fig.width=7.5, fig.cap="Boxplot mapping Sex as x"----
plotBoxWhisker(data = pkRatioData,
               metaData = pkRatioMetaData,
               dataMapping = xSexMap)

## ----boxplot country fill, fig.height=5, fig.width=7.5, fig.cap="Boxplot mapping Country as fill"----
plotBoxWhisker(data = pkRatioData,
               metaData = pkRatioMetaData,
               dataMapping = fillPopMap)

## ----boxplot sex fill, fig.height=5, fig.width=7.5, fig.cap="Boxplot mapping Sex as fill"----
plotBoxWhisker(data = pkRatioData,
               metaData = pkRatioMetaData,
               dataMapping = fillSexMap)

## ----boxplot country x sex fill, fig.height=5, fig.width=7.5, fig.cap="Boxplot mapping Country as x and Sex as fill"----
plotBoxWhisker(data = pkRatioData,
               metaData = pkRatioMetaData,
               dataMapping = xPopFillSexMap)

## ----boxplot country fill sex x, fig.height=5, fig.width=7.5, fig.cap="Boxplot mapping Sex as x and Country as fill"----
plotBoxWhisker(data = pkRatioData,
               metaData = pkRatioMetaData,
               dataMapping = xSexFillPopMap)

## ----aggregation functions 1, fig.height=5, fig.width=7.5, fig.cap="Boxplot mapping Country as x, Sex as fill and assuming normal distribution"----

normMap <- BoxWhiskerDataMapping$new(x = "Country",
                                     y = "Age",
                                     fill = "Sex",
                                     ymin = tlfStatFunctions$`mean-1.96sd`,
                                     middle = tlfStatFunctions$mean,
                                     ymax = tlfStatFunctions$`mean+1.96sd`)

normBoxplot <- plotBoxWhisker(data = pkRatioData,
                              metaData = pkRatioMetaData,
                              dataMapping = normMap)
normBoxplot

## ----aggregation functions 2, fig.height=5, fig.width=7.5, fig.cap="Boxplot mapping Country as x, Sex as fill and assuming normal distribution"----

normMap2 <- BoxWhiskerDataMapping$new(x = "Country",
                                     y = "Age",
                                     fill = "Sex",
                                     ymin = tlfStatFunctions$`mean-1.96sd`,
                                     lower = tlfStatFunctions$`mean-sd`,
                                     middle = tlfStatFunctions$mean,
                                     upper = tlfStatFunctions$`mean+sd`,
                                     ymax = tlfStatFunctions$`mean+1.96sd`)

normBoxplot2 <- plotBoxWhisker(data = pkRatioData,
                              metaData = pkRatioMetaData,
                              dataMapping = normMap2)
normBoxplot2

## ----outlier function, fig.height=5, fig.width=7.5, fig.cap="Boxplot mapping Country as x, Sex as fill and assuming normal distribution"----

outlierMap <- BoxWhiskerDataMapping$new(x = "Country",
                                        y = "Age",
                                        fill = "Sex",
                                        ymin = tlfStatFunctions$`Percentile10%`,
                                        ymax = tlfStatFunctions$`Percentile90%`,
                                        minOutlierLimit = tlfStatFunctions$`Percentile10%`,
                                        maxOutlierLimit = tlfStatFunctions$`Percentile90%`)

outlierBoxplot <- plotBoxWhisker(data = pkRatioData,
                              metaData = pkRatioMetaData,
                              dataMapping = outlierMap)
outlierBoxplot

## ----boxplot update configuration, fig.height=5, fig.width=7.5, fig.cap="Boxplot with updated plot configuration"----
# Define a PlotConfiguration object using smart mapping
boxplotConfiguration <- BoxWhiskerPlotConfiguration$new(data = pkRatioData,
                                                        metaData = pkRatioMetaData,
                                                        dataMapping = xPopFillSexMap)

# Change the properties of the box colors
boxplotConfiguration$ribbons$fill <- c("pink", "dodgerblue")
boxplotConfiguration$ribbons$color <- "black"

# Change the properties of the points (outliers)
boxplotConfiguration$points$size <- 2
boxplotConfiguration$points$shape <- Shapes$diamond

plotBoxWhisker(data = pkRatioData,
               metaData = pkRatioMetaData,
               dataMapping = xPopFillSexMap,
               plotConfiguration = boxplotConfiguration)

## ----box plot measure, results='as.is'----------------------------------------
boxplotSummary <- outlierMap$getBoxWhiskerLimits(pkRatioData)

knitr::kable(boxplotSummary, digits = 2)

## ----get outliers, results='as.is'--------------------------------------------
outliers <- outlierMap$getOutliers(pkRatioData)
outliers <- outliers[, c("Age", "minOutlierLimit", "maxOutlierLimit", "minOutliers", "maxOutliers")]

knitr::kable(utils::head(outliers), digits = 2)

