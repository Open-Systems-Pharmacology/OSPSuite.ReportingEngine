## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
require(tlf)

## ----load theme, echo=FALSE---------------------------------------------------
vignetteTheme <- loadThemeFromJson(system.file("extdata", "template-theme.json", package = "tlf"))
useTheme(vignetteTheme)

## ----workflow illustration, out.width="100%", include=TRUE, fig.align="center", echo=FALSE----
# echo=FALSE prints only code chunk output
knitr::include_graphics("workflow.png")

## ----naming convention, echo = FALSE, results='asis'--------------------------
# This small script gives a fast way to introduce the nomenclature of the classes and functions
plotNames <- c("PKRatio", "DDIRatio", "IndividualIdProfile", "ObsVsPred", "Histogram", "BoxWhisker")
classesNames <- c("DataMapping", "PlotConfiguration")
functionNames <- c("plot")

conventionTable <- data.frame(sapply(classesNames, function(x){paste0(plotNames, x)}), 
           sapply(functionNames, function(x){paste0(x, plotNames)}),
           row.names = plotNames)


knitr::kable(conventionTable)

## ----get test data, echo=FALSE, results='asis'--------------------------------
testData <- read.csv(system.file("extdata", "ospsuite-data.csv", package = "tlf"), check.names = FALSE, stringsAsFactors = FALSE)
knitr::kable(head(testData[,1:6])) #For aesthetics of the table align='c', digits =2)

## ----get test metadata, results='asis', echo=FALSE----------------------------
metaDataTable <- read.csv(system.file("extdata", "ospsuite-metadata.csv", package = "tlf"), check.names = FALSE, stringsAsFactors = FALSE)
knitr::kable(metaDataTable)

## ----get test metadata as list, include=FALSE---------------------------------
testMetaData <- list()
for(variableIndex in 1:nrow(metaDataTable)){
  testMetaData[[metaDataTable$Variable[variableIndex]]] <- list(dimension = metaDataTable$Dimension[variableIndex],
                                                                unit = metaDataTable$Unit[variableIndex])
}

## ----aggregate example, results='asis'----------------------------------------
aggSummary <- AggregationSummary$new(data = testData , 
                                     metaData = testMetaData,
                                     xColumnNames = "IndividualId",
                                     groupingColumnNames = "Gender",
                                     yColumnNames = "Organism|VenousBlood|Volume",
                                     aggregationFunctionsVector = c(min,mean),
                                     aggregationFunctionNames =c("Simulated Min",
                                                                 "Simulated Mean"),
                                     aggregationUnitsVector = c("l","l"),
                                     aggregationDimensionsVector = c("Volume",
                                                                     "Volume"))

## ----show aggregation summary, echo=FALSE, results='asis'---------------------
knitr::kable(head(aggSummary$dfHelper, digits=2))

## ----show meta data of aggregation, results='asis'----------------------------
# Currently issue with metaData of Gender
aggSummary$metaDataHelper[[2]] <- NULL
aggMetaData <- data.frame("unit" = sapply(aggSummary$metaDataHelper, function(x){x$unit}),
                          "dimension" = sapply(aggSummary$metaDataHelper, function(x){x$dimension}))

knitr::kable(aggMetaData)

## ----grouping 2 variables, results='asis'-------------------------------------
# Grouping by variable names:
grouping1 <- Grouping$new(c("Compound","Dose"))

## ----grouping 2 variable with label, results='asis'---------------------------
# Grouping by variable names and overwriting the default label:
grouping2 <- Grouping$new(group = c("Compound","Dose"), label = "Compound & Dose")

## ----grouping using data.frame, results='asis'--------------------------------
# Grouping using a data.frame:
mappingDataFrame <- data.frame(Compound = c("Aspirin","Aspirin","Sugar","Sugar"),
                               Dose = c(6,3,6,3),  
                               "Compound & Dose"  = c("6mg of Aspirin",
                                                      "3mg of Aspirin",
                                                      "6mg of Sugar",
                                                      "3mg of Sugar"),
                               check.names = FALSE)
knitr::kable(mappingDataFrame)
grouping3 <- Grouping$new(group = mappingDataFrame)

## ----grouping show captions, results='asis'-----------------------------------
# Apply the mapping to get the grouping captions:
groupingsDataFrame <- data.frame(testData$IndividualId,
                                 testData$Dose,
                                 testData$Compound,
                                 grouping1$getCaptions(testData),
                                 grouping2$getCaptions(testData),
                                 grouping3$getCaptions(testData))

names(groupingsDataFrame) <- c("IndividualId", "Dose", "Compound",
                               grouping1$label, grouping2$label, grouping3$label)

# Show results for all groupings:
knitr::kable(groupingsDataFrame)

## ----binning age, results='asis'----------------------------------------------
# Grouping using a data.frame:
binningDataFrame <- data.frame(Age = I( list(c(0,6),c(7,100)) ), 
                               "Age Range" = c("Age 6 or lower",
                                               "Above age 6"),
                               check.names = FALSE)

## ----grouping with age bins, results='asis'-----------------------------------
grouping4 <- Grouping$new(group = binningDataFrame)

## ----show grouping with age bins, results='asis'------------------------------
# Apply the mapping to get the grouping captions:
testData$Age <- testData$`Organism|Age`
binnedGroupingsDataFrame <- data.frame(testData$IndividualId,
                                       testData$Age,
                                       grouping4$getCaptions(testData)) 

names(binnedGroupingsDataFrame) <- c("IndividualId", "Age", grouping4$label)

# Show results for all groupings:
knitr::kable(binnedGroupingsDataFrame)

## ----group mapping class, results='asis'--------------------------------------
# Map groups to aesthtic properties
groups1 <- GroupMapping$new(color =  grouping2 )

## ---- results='asis'----------------------------------------------------------
# Map groups to aesthtic properties
groups2 <- GroupMapping$new(color = c("Compound", "Dose"))

## ---- results='asis'----------------------------------------------------------
# Map groups to aesthetic properties
groups3 <- GroupMapping$new(color = Grouping$new(group = c("Compound", "Dose"),
                                                  label = c("Compound & Dose")))

## ----data mapping, results='asis'---------------------------------------------
tpMapping <- XYGDataMapping$new(x="IndividualId", y="Organism|VenousBlood|Volume")
knitr::kable(tpMapping$checkMapData(data = testData,
                                            metaData = IndividualIdProfileMetaData))

## ----data mapping groups 1, results='asis'------------------------------------
# Re-use the variable groups previously defined
tpMapping <- XYGDataMapping$new(x="IndividualId", y="Organism|VenousBlood|Volume", 
                                        groupMapping = groups1)

knitr::kable(tpMapping$checkMapData(data = testData))

